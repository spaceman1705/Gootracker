package com.example.bacadata.paketku;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bacadata.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AdapterDataku extends RecyclerView.Adapter<AdapterDataku.ViewHolder> implements Filterable {
    Context context;
    List<Dataku> list;
    List<Dataku> listFull;

    public AdapterDataku(Context context, List<Dataku> list) {
        this.context = context;
        this.list = list;
        listFull = new ArrayList<>(list);
    }
    @NonNull
    @Override
    public AdapterDataku.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_data_leot,parent,false);
        return new AdapterDataku.ViewHolder(view);
        //return null;
    }
    @Override
    public void onBindViewHolder(@NonNull AdapterDataku.ViewHolder holder, int position) {

        holder.teksViu_data.setText(list.get(position).getIsi());
        holder.statusdata.setText(list.get(position).getStatus());
        holder.waktudata.setText(list.get(position).getWaktu());
    }
    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public Filter getFilter() {

        return FilterUser;
    }
    private Filter FilterUser = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            String searchText = charSequence.toString().toLowerCase();
            List<Dataku>tempList=new ArrayList<>();
            if (searchText.length()==0||searchText.isEmpty())
            {
                tempList.addAll(listFull);
            }
            else
            {
                for (Dataku item:listFull)
                {
                    if (item.getIsi().toLowerCase().contains(searchText))
                    {
                        tempList.add(item);
                    }
                    if (item.getStatus().toLowerCase().contains(searchText))
                    {
                        tempList.add(item);
                    }
                }
            }
            FilterResults filterResults= new FilterResults();
            filterResults.values=tempList;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            list.clear();
            list.addAll((Collection<?extends Dataku>)filterResults.values);
            notifyDataSetChanged();
        }
    };

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView teksViu_data,statusdata,waktudata;
        //ImageButton tbl_Hapus,tbl_edit;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            statusdata=itemView.findViewById(R.id.status);
            teksViu_data=itemView.findViewById(R.id.teks_viu_data);
            waktudata=itemView.findViewById(R.id.waktu);
        }
    }
}
