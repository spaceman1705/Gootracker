package com.example.bacadata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }
    public void button1(View view){
        Intent intent=new Intent(Dashboard.this,MainActivity.class);
        startActivity(intent);
    }
    public void button2(View view){
        Intent intent=new Intent(Dashboard.this,MainActivity2.class);
        startActivity(intent);
    }
    public void button3(View view){
        Intent intent=new Intent(Dashboard.this,MainActivity3.class);
        startActivity(intent);
    }
}