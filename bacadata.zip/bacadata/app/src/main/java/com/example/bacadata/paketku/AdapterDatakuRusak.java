package com.example.bacadata.paketku;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bacadata.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AdapterDatakuRusak extends RecyclerView.Adapter<AdapterDatakuRusak.ViewHolder> implements Filterable {
    Context context;
    List<Dataku> list;
    List<Dataku> listFull;

    public AdapterDatakuRusak(Context context, List<Dataku> list) {
        this.context = context;
        this.list = list;
        listFull = new ArrayList<>(list);
    }
    @NonNull
    @Override
    public AdapterDatakuRusak.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view2 = LayoutInflater.from(context).inflate(R.layout.list_data_leot_rusak,parent,false);
        return new ViewHolder(view2);
        //return null;
    }
    @Override
    public void onBindViewHolder(@NonNull AdapterDatakuRusak.ViewHolder holder, int position) {

        holder.teksViu_data.setText(list.get(position).getIsi());
        holder.waktudata.setText(list.get(position).getWaktu());
        holder.whydata.setText(list.get(position).getMasalah());
    }
    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public Filter getFilter() {
        return FilterUser;
    }
    private final Filter FilterUser = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            String searchText = charSequence.toString().toLowerCase();
            List<Dataku> tempList = new ArrayList<>();
            if (searchText.length() == 0) {
                tempList.addAll(listFull);
            } else {
                for (Dataku item : listFull) {
                    if (item.getIsi().toLowerCase().contains(searchText)) {
                        tempList.add(item);
                    }
                }
            }
            FilterResults filterResults = new FilterResults();
            filterResults.values = tempList;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            list.clear();
            list.addAll((Collection<?extends Dataku>)filterResults.values);
            notifyDataSetChanged();
        }
    };

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView teksViu_data,waktudata,whydata;
        //ImageButton tbl_Hapus,tbl_edit;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            teksViu_data=itemView.findViewById(R.id.teks_viu_data);
            waktudata=itemView.findViewById(R.id.waktu);
            whydata=itemView.findViewById(R.id.masalah);
            //tbl_Hapus=itemView.findViewById(R.id.tbl_hapus);
            //tbl_edit=itemView.findViewById(R.id.tbl_edit);
        }
    }
}
