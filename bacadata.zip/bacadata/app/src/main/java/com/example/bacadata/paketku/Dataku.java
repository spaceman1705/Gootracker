package com.example.bacadata.paketku;

public class Dataku {
    String isi;
    String kunci;
    String masalah;
    String status;
    String waktu;
    public Dataku(){};
    public Dataku(String isi, String kunci, String masalah, String status, String waktu) {
        this.kunci = kunci;
        this.isi = isi;
        this.status=status;
        this.waktu=waktu;
        this.masalah=masalah;
    }
    public String getKunci() {
        return kunci;
    }

    public void setKunci(String kunci) {
        this.kunci = kunci;
    }

    public String getIsi() {
        return isi;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status){this.status=status;}

    public String getWaktu() {
        return waktu;
    }

    public void setSWaktu(String waktu){this.waktu=waktu;}

    public String getMasalah() {
        return masalah;
    }

    public void setMasalah(String masalah){this.masalah=masalah;}
}
