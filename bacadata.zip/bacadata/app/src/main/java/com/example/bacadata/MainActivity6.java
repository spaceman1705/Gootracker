package com.example.bacadata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.bacadata.paketku.AdapterDatakuRusak;
import com.example.bacadata.paketku.Dataku;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity6 extends AppCompatActivity {
    RecyclerView recyclerView;
    SearchView searchView;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Dataku");
    List<Dataku> list=new ArrayList<>();
    AdapterDatakuRusak adapterdataku;
    TextView BibitBD,BibitDT,BibitRS,BibitMT;
    int bd=0,dt=0,rs=0,mt=0;
    String bds,bdt,brs,bmt,why;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        BibitRS=findViewById(R.id.jmlrs);
        recyclerView=findViewById(R.id.resaikel_viu);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        bacaData();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String s) {
                adapterdataku.getFilter().filter(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
    private void bacaData() {
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                list.clear();
                bd=dt=rs=0;
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Dataku value = snapshot.getValue(Dataku.class);
                    if (value.getIsi().contains("ZA")&&value.getStatus().contains("Rusak")){
                        list.add(value);
                        if(value.getStatus().contains("Rusak")){
                            rs++;
                            brs=String.valueOf(rs);
                            BibitRS.setText("Bibit Rusak : "+brs);
                        }
                    }

                }
                adapterdataku=new AdapterDatakuRusak(MainActivity6.this,list);
                recyclerView.setAdapter(adapterdataku);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });
    }
}